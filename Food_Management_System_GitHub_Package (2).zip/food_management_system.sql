-- Food Management System | MySQL 8+
-- Sample learning implementation. Match this with your team's original schema before submission.
CREATE DATABASE IF NOT EXISTS FoodManagementSystem;
USE FoodManagementSystem;

SET FOREIGN_KEY_CHECKS=0;
DROP VIEW IF EXISTS Order_Summary;
DROP TABLE IF EXISTS Reviews, Deliveries, Payments, Order_Coupons, Order_Items, Orders,
Coupons, Delivery_Partners, Food_Items, Categories, Addresses, Customers, Restaurants;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE Customers (
 customer_id INT PRIMARY KEY AUTO_INCREMENT,
 customer_name VARCHAR(100) NOT NULL,
 phone VARCHAR(15) UNIQUE,
 email VARCHAR(120) UNIQUE,
 created_at DATE
);
CREATE TABLE Addresses (
 address_id INT PRIMARY KEY AUTO_INCREMENT,
 customer_id INT NOT NULL,
 address_line VARCHAR(200) NOT NULL,
 city VARCHAR(80) NOT NULL,
 postal_code VARCHAR(12),
 FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);
CREATE TABLE Restaurants (
 restaurant_id INT PRIMARY KEY AUTO_INCREMENT,
 restaurant_name VARCHAR(120) NOT NULL,
 location VARCHAR(150),
 phone VARCHAR(15),
 rating DECIMAL(2,1) DEFAULT 0.0
);
CREATE TABLE Categories (
 category_id INT PRIMARY KEY AUTO_INCREMENT,
 category_name VARCHAR(80) NOT NULL UNIQUE
);
CREATE TABLE Food_Items (
 food_id INT PRIMARY KEY AUTO_INCREMENT,
 restaurant_id INT NOT NULL,
 category_id INT NOT NULL,
 food_name VARCHAR(120) NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 is_available BOOLEAN DEFAULT TRUE,
 FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id),
 FOREIGN KEY (category_id) REFERENCES Categories(category_id)
);
CREATE TABLE Delivery_Partners (
 partner_id INT PRIMARY KEY AUTO_INCREMENT,
 partner_name VARCHAR(100) NOT NULL,
 phone VARCHAR(15) UNIQUE,
 vehicle_type VARCHAR(40)
);
CREATE TABLE Orders (
 order_id INT PRIMARY KEY AUTO_INCREMENT,
 customer_id INT NOT NULL,
 address_id INT NOT NULL,
 order_date DATETIME NOT NULL,
 order_status VARCHAR(30) NOT NULL DEFAULT 'Placed',
 total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
 FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
 FOREIGN KEY (address_id) REFERENCES Addresses(address_id)
);
CREATE TABLE Order_Items (
 order_item_id INT PRIMARY KEY AUTO_INCREMENT,
 order_id INT NOT NULL,
 food_id INT NOT NULL,
 quantity INT NOT NULL,
 unit_price DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES Orders(order_id),
 FOREIGN KEY (food_id) REFERENCES Food_Items(food_id)
);
CREATE TABLE Coupons (
 coupon_id INT PRIMARY KEY AUTO_INCREMENT,
 coupon_code VARCHAR(30) NOT NULL UNIQUE,
 discount_percent DECIMAL(5,2) NOT NULL,
 valid_until DATE,
 is_active BOOLEAN DEFAULT TRUE
);
CREATE TABLE Order_Coupons (
 order_id INT PRIMARY KEY,
 coupon_id INT NOT NULL,
 discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
 FOREIGN KEY (order_id) REFERENCES Orders(order_id),
 FOREIGN KEY (coupon_id) REFERENCES Coupons(coupon_id)
);
CREATE TABLE Payments (
 payment_id INT PRIMARY KEY AUTO_INCREMENT,
 order_id INT NOT NULL UNIQUE,
 payment_date DATETIME,
 payment_method VARCHAR(30),
 payment_status VARCHAR(30) NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);
CREATE TABLE Deliveries (
 delivery_id INT PRIMARY KEY AUTO_INCREMENT,
 order_id INT NOT NULL UNIQUE,
 partner_id INT,
 dispatched_at DATETIME,
 delivered_at DATETIME,
 delivery_status VARCHAR(30) NOT NULL DEFAULT 'Assigned',
 FOREIGN KEY (order_id) REFERENCES Orders(order_id),
 FOREIGN KEY (partner_id) REFERENCES Delivery_Partners(partner_id)
);
CREATE TABLE Reviews (
 review_id INT PRIMARY KEY AUTO_INCREMENT,
 customer_id INT NOT NULL,
 restaurant_id INT NOT NULL,
 order_id INT,
 rating INT NOT NULL,
 review_text VARCHAR(500),
 review_date DATE,
 FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
 FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id),
 FOREIGN KEY (order_id) REFERENCES Orders(order_id),
 CHECK (rating BETWEEN 1 AND 5)
);

-- Sample data
INSERT INTO Customers (customer_name,phone,email,created_at) VALUES
('Sandhya','9000000001','sandhya@example.com','2026-01-10'),
('Ravi','9000000002','ravi@example.com','2026-02-15'),
('Priya','9000000003','priya@example.com','2026-03-20'),
('Arjun','9000000004','arjun@example.com','2026-04-05'),
('Meena','9000000005','meena@example.com','2026-05-11');
INSERT INTO Addresses (customer_id,address_line,city,postal_code) VALUES
(1,'Beach Road','Visakhapatnam','530001'),
(2,'Madhurawada','Visakhapatnam','530048'),
(3,'Dwaraka Nagar','Visakhapatnam','530016'),
(4,'Seethammadhara','Visakhapatnam','530013'),
(5,'Gajuwaka','Visakhapatnam','530026');
INSERT INTO Restaurants (restaurant_name,location,phone,rating) VALUES
('Spicy Hub','Madhurawada','8910000001',4.3),
('Food Palace','Dwaraka Nagar','8910000002',4.1),
('Green Bowl','Beach Road','8910000003',4.5);
INSERT INTO Categories (category_name) VALUES
('Biryani'),('Rice'),('Starters'),('Desserts'),('Beverages');
INSERT INTO Food_Items (restaurant_id,category_id,food_name,price,is_available) VALUES
(1,1,'Chicken Biryani',250,TRUE),(1,2,'Veg Fried Rice',160,TRUE),
(2,1,'Veg Biryani',180,TRUE),(2,3,'Paneer 65',190,TRUE),
(3,2,'Brown Rice Bowl',210,TRUE),(3,4,'Gulab Jamun',80,TRUE),
(1,5,'Lime Soda',60,FALSE);
INSERT INTO Delivery_Partners (partner_name,phone,vehicle_type) VALUES
('Kiran','9110000001','Bike'),('Suresh','9110000002','Scooter'),('Anu','9110000003','Bike');
INSERT INTO Orders (customer_id,address_id,order_date,order_status,total_amount) VALUES
(1,1,'2026-10-01 12:30:00','Delivered',310),
(2,2,'2026-10-02 19:15:00','Preparing',370),
(3,3,'2026-10-03 13:05:00','Delivered',260),
(1,1,'2026-10-04 20:00:00','Cancelled',180),
(4,4,'2026-10-05 18:45:00','Delivered',290),
(5,5,'2026-10-06 14:20:00','Placed',210);
INSERT INTO Order_Items (order_id,food_id,quantity,unit_price) VALUES
(1,1,1,250),(1,7,1,60),(2,3,1,180),(2,4,1,190),(3,2,1,160),
(3,6,1,80),(4,3,1,180),(5,1,1,250),(6,5,1,210);
INSERT INTO Coupons (coupon_code,discount_percent,valid_until,is_active) VALUES
('WELCOME10',10,'2027-12-31',TRUE),('FOOD5',5,'2027-06-30',TRUE),('OLD20',20,'2025-12-31',FALSE);
INSERT INTO Order_Coupons (order_id,coupon_id,discount_amount) VALUES (1,1,31),(3,2,13);
INSERT INTO Payments (order_id,payment_date,payment_method,payment_status,amount) VALUES
(1,'2026-10-01 12:35:00','UPI','Paid',279),
(2,'2026-10-02 19:16:00','Card','Pending',370),
(3,'2026-10-03 13:10:00','Cash','Paid',247),
(4,'2026-10-04 20:01:00','UPI','Refunded',180),
(5,'2026-10-05 18:50:00','UPI','Paid',290);
INSERT INTO Deliveries (order_id,partner_id,dispatched_at,delivered_at,delivery_status) VALUES
(1,1,'2026-10-01 12:45:00','2026-10-01 13:10:00','Delivered'),
(2,2,'2026-10-02 19:40:00',NULL,'In Transit'),
(3,3,'2026-10-03 13:20:00','2026-10-03 13:50:00','Delivered'),
(5,1,'2026-10-05 19:00:00','2026-10-05 19:35:00','Delivered');
INSERT INTO Reviews (customer_id,restaurant_id,order_id,rating,review_text,review_date) VALUES
(1,1,1,5,'Tasty food and quick delivery','2026-10-01'),
(3,2,3,4,'Good taste','2026-10-03'),
(4,1,5,4,'Fresh and delicious','2026-10-05');

-- 40 SQL queries
-- Q01 All customers
SELECT * FROM Customers;
-- Q02 All restaurants
SELECT * FROM Restaurants;
-- Q03 Food names and prices
SELECT food_name,price FROM Food_Items;
-- Q04 Food costing more than 180
SELECT food_name,price FROM Food_Items WHERE price>180;
-- Q05 Available food items
SELECT * FROM Food_Items WHERE is_available=TRUE;
-- Q06 Sort food by price, highest first
SELECT food_name,price FROM Food_Items ORDER BY price DESC;
-- Q07 Count customers
SELECT COUNT(*) AS total_customers FROM Customers;
-- Q08 Average food price
SELECT ROUND(AVG(price),2) AS average_food_price FROM Food_Items;
-- Q09 Cheapest food
SELECT food_name,price FROM Food_Items WHERE price=(SELECT MIN(price) FROM Food_Items);
-- Q10 Most expensive food
SELECT food_name,price FROM Food_Items WHERE price=(SELECT MAX(price) FROM Food_Items);
-- Q11 Food with restaurant name
SELECT f.food_name,r.restaurant_name,f.price FROM Food_Items f JOIN Restaurants r ON f.restaurant_id=r.restaurant_id;
-- Q12 Food with category
SELECT f.food_name,c.category_name,f.price FROM Food_Items f JOIN Categories c ON f.category_id=c.category_id;
-- Q13 Customers and orders
SELECT c.customer_name,o.order_id,o.order_date,o.order_status,o.total_amount FROM Customers c JOIN Orders o ON c.customer_id=o.customer_id;
-- Q14 Orders placed by Sandhya
SELECT o.* FROM Orders o JOIN Customers c ON o.customer_id=c.customer_id WHERE c.customer_name='Sandhya';
-- Q15 Count orders by status
SELECT order_status,COUNT(*) AS order_count FROM Orders GROUP BY order_status;
-- Q16 Total order value by customer
SELECT c.customer_name,SUM(o.total_amount) AS total_order_value FROM Customers c JOIN Orders o ON c.customer_id=o.customer_id GROUP BY c.customer_id,c.customer_name;
-- Q17 Customers with more than one order
SELECT c.customer_name,COUNT(o.order_id) AS order_count FROM Customers c JOIN Orders o ON c.customer_id=o.customer_id GROUP BY c.customer_id,c.customer_name HAVING COUNT(o.order_id)>1;
-- Q18 Orders and payment details
SELECT o.order_id,o.total_amount,p.payment_method,p.payment_status,p.amount FROM Orders o LEFT JOIN Payments p ON o.order_id=p.order_id;
-- Q19 Paid payments
SELECT * FROM Payments WHERE payment_status='Paid';
-- Q20 Total collected from paid payments
SELECT SUM(amount) AS collected_amount FROM Payments WHERE payment_status='Paid';
-- Q21 Orders and delivery status
SELECT o.order_id,o.order_status,d.delivery_status,d.dispatched_at,d.delivered_at FROM Orders o LEFT JOIN Deliveries d ON o.order_id=d.order_id;
-- Q22 Deliveries not yet delivered
SELECT order_id,delivery_status FROM Deliveries WHERE delivery_status<>'Delivered';
-- Q23 Delivery partners and assigned orders
SELECT dp.partner_name,d.order_id,d.delivery_status FROM Delivery_Partners dp JOIN Deliveries d ON dp.partner_id=d.partner_id;
-- Q24 Average restaurant rating
SELECT ROUND(AVG(rating),2) AS average_restaurant_rating FROM Restaurants;
-- Q25 Restaurants rated 4.2 or higher
SELECT restaurant_name,rating FROM Restaurants WHERE rating>=4.2 ORDER BY rating DESC;
-- Q26 Average customer review rating per restaurant
SELECT r.restaurant_name,ROUND(AVG(rv.rating),2) AS average_review_rating FROM Restaurants r JOIN Reviews rv ON r.restaurant_id=rv.restaurant_id GROUP BY r.restaurant_id,r.restaurant_name;
-- Q27 Reviews with customer and restaurant names
SELECT c.customer_name,r.restaurant_name,rv.rating,rv.review_text FROM Reviews rv JOIN Customers c ON rv.customer_id=c.customer_id JOIN Restaurants r ON rv.restaurant_id=r.restaurant_id;
-- Q28 Categories with more than one food item
SELECT c.category_name,COUNT(f.food_id) AS item_count FROM Categories c JOIN Food_Items f ON c.category_id=f.category_id GROUP BY c.category_id,c.category_name HAVING COUNT(f.food_id)>1;
-- Q29 Available food count by restaurant
SELECT r.restaurant_name,COUNT(f.food_id) AS available_items FROM Restaurants r LEFT JOIN Food_Items f ON r.restaurant_id=f.restaurant_id AND f.is_available=TRUE GROUP BY r.restaurant_id,r.restaurant_name;
-- Q30 Food priced above average
SELECT food_name,price FROM Food_Items WHERE price>(SELECT AVG(price) FROM Food_Items);
-- Q31 Order line totals
SELECT oi.order_id,f.food_name,oi.quantity,oi.unit_price,(oi.quantity*oi.unit_price) AS line_total FROM Order_Items oi JOIN Food_Items f ON oi.food_id=f.food_id;
-- Q32 Most frequently ordered food items
SELECT f.food_name,SUM(oi.quantity) AS quantity_ordered FROM Food_Items f JOIN Order_Items oi ON f.food_id=oi.food_id GROUP BY f.food_id,f.food_name ORDER BY quantity_ordered DESC;
-- Q33 Customers with no orders
SELECT c.customer_id,c.customer_name FROM Customers c LEFT JOIN Orders o ON c.customer_id=o.customer_id WHERE o.order_id IS NULL;
-- Q34 Active coupons not expired
SELECT coupon_code,discount_percent,valid_until FROM Coupons WHERE is_active=TRUE AND (valid_until IS NULL OR valid_until>=CURDATE());
-- Q35 Orders with applied coupon
SELECT o.order_id,cp.coupon_code,oc.discount_amount FROM Orders o JOIN Order_Coupons oc ON o.order_id=oc.order_id JOIN Coupons cp ON oc.coupon_id=cp.coupon_id;
-- Q36 Total discount by coupon
SELECT cp.coupon_code,SUM(oc.discount_amount) AS total_discount FROM Coupons cp JOIN Order_Coupons oc ON cp.coupon_id=oc.coupon_id GROUP BY cp.coupon_id,cp.coupon_code;
-- Q37 Orders per day
SELECT DATE(order_date) AS order_day,COUNT(*) AS orders_count FROM Orders GROUP BY DATE(order_date) ORDER BY order_day;
-- Q38 Item sales by restaurant
SELECT r.restaurant_name,SUM(oi.quantity*oi.unit_price) AS item_sales FROM Restaurants r JOIN Food_Items f ON r.restaurant_id=f.restaurant_id JOIN Order_Items oi ON f.food_id=oi.food_id GROUP BY r.restaurant_id,r.restaurant_name ORDER BY item_sales DESC;
-- Q39 Label orders by amount using CASE
SELECT order_id,total_amount,CASE WHEN total_amount>=300 THEN 'High Value' WHEN total_amount>=200 THEN 'Medium Value' ELSE 'Low Value' END AS order_value_category FROM Orders;
-- Q40 Create and use a view
CREATE OR REPLACE VIEW Order_Summary AS SELECT o.order_id,c.customer_name,o.order_date,o.order_status,o.total_amount FROM Orders o JOIN Customers c ON o.customer_id=c.customer_id;
SELECT * FROM Order_Summary;

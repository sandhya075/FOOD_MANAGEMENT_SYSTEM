# Food Management System – MySQL Project

## Project Overview
A relational database sample for managing customers, delivery addresses, restaurants, menu categories, food items, orders, order items, payments, delivery partners, deliveries, coupons, and reviews.

**Important:** This package is a sample implementation for learning and GitHub presentation. It is not verified as the exact SQL from your team's existing repository. Compare and adapt it to your team's actual tables, data, and contribution before submitting.

## Objectives
- Maintain customer, restaurant, and menu information.
- Store orders and their food items.
- Track payments and delivery status.
- Manage discounts and customer feedback.
- Practice joins, aggregate functions, subqueries, grouping, CASE, and views.

## Technologies
- MySQL 8+
- SQL
- MySQL Workbench
- Git/GitHub

## Database Tables
1. Customers
2. Addresses
3. Restaurants
4. Categories
5. Food_Items
6. Delivery_Partners
7. Orders
8. Order_Items
9. Coupons
10. Order_Coupons
11. Payments
12. Deliveries
13. Reviews

This sample has 13 tables. If your team's original project has exactly 12, update the schema and this list to match the original project.

## Files
- `food_management_system.sql` – schema, sample data, and 40 SQL queries
- `ER_Diagram.png` – entity relationship diagram
- `ER_Relationships.txt` – relationship summary
- `README.md` – project overview and instructions

## How to Run
1. Install MySQL Server and MySQL Workbench.
2. Open `food_management_system.sql` in MySQL Workbench.
3. Execute the script from top to bottom.
4. Refresh the Schemas panel and select `FoodManagementSystem`.
5. Run individual queries from the `40 SQL queries` section.

## SQL Concepts Covered
- CREATE DATABASE / CREATE TABLE / INSERT
- Primary keys and foreign keys
- SELECT, WHERE, ORDER BY
- COUNT, SUM, AVG, MIN, MAX
- INNER JOIN and LEFT JOIN
- GROUP BY and HAVING
- Subqueries
- CASE statements
- Views and date functions

## Example Business Questions
- Which menu items cost more than a chosen price?
- How many orders are in each status?
- What amount has been collected from paid payments?
- Which food items are ordered most frequently?
- What are the average restaurant review ratings?
- Which deliveries are still in transit?

## GitHub Upload
Upload these files to your repository:
- `food_management_system.sql`
- `ER_Diagram.png`
- `ER_Relationships.txt`
- `README.md`

If this is a team project, label it **Team Project** and describe only the tasks you personally completed.

## Team / Contribution
Add your team members and your actual contribution here before publishing.
